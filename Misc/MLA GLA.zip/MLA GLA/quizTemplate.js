var quizAnswerKey = new Array();
var quizQuestions = new Array();
var quizAnswers = new Array();
var curQuestionId = 0; // After questions are loaded, will have number of total questions
var correct = 0; // Questions answered correctly
var answered = 0; // Questions answered total
var curQuiz;

function display()
{
	// Display questions on page
	if(answered == 0 && getCookie("answered") != "")
	{
		answered = parseInt(getCookie("answered"));
	}
	if(correct == 0 && getCookie("correct") != "")
	{
		correct = parseInt(getCookie("correct"));
	}
	
	for(var i = 0; i < quizQuestions.length; ++i) // i = Question number
	{
		document.getElementById("quiz").innerHTML += "<div class=\"questionContainer\"><h3>" + quizQuestions[i] + "</h3>";
		
		for(var j = 0; j < quizAnswers[i].length; j++) // j = Answer number
		{
			var prefix = "";
			var postfix = "";
			document.getElementById("quiz").innerHTML += "<div id='d" + i + "," + j + "'>";
			
			// Loads questions already answered
			if(getCookie(i) != "")
			{
				if(parseInt(getCookie(i)) == j)
				{
					if(answered !== curQuestionId)
					{
						prefix = "<span class='selected'>";
						postfix = "</span>";
					}
					else
					{
						if(parseInt(getCookie(i)) == quizAnswerKey[i])
						{
							
							prefix = "<font color='green'>";
							postfix = "</font>";
						}
						else
						{
							prefix = "<font color='red'>";
							postfix = "</font>";
						}
					}
				}
			}
			document.getElementById("quiz").innerHTML += "<a href='javascript:void(0)' class='link' id='" + i + "," + j + "' onClick='answerQuestion(\"" + i + "," + j + "\")'>" + prefix + (j+1) + ") " + quizAnswers[i][j] + postfix + "</a>";
			document.getElementById("quiz").innerHTML += "<br></div>";
			document.getElementById("quiz").innerHTML += "</div>";//closes questionContainer div
		}
	}
	
	// Check if the quiz is finished
		
	if(answered == curQuestionId)
	{
		document.getElementById("buttons").innerHTML = '<input type="button" value="Continue" onClick="quizFinished();" />';
		setCookie("submitted", 1, 1);
		//quizFinished();
	}
	else
	{
		document.getElementById("buttons").innerHTML = '<input type="button" value="Submit Quiz" onClick="location.reload();" />';
	}
	debug();
}

function answerQuestion(answer)
{
	var a = answer.split(","); // Answers are determined by 'question,answer'.
	var question=a[0];
	var ans=parseInt(a[1]);
	
	if(getCookie(question) == "") // The question hasn't been answered yet
	{
		answered++;
		
		setCookie("answered", answered, 1);
		setCookie(question, ans, 1);
		
		//var inner = document.getElementById("" + question + "," + ans).innerHTML;
		
		checkAnswer(question, ans);
		
		// Check if we're at the end of the quiz
		if(answered == curQuestionId)
		{
			//quizFinished();
		}
	}
	else if(getCookie("submitted") == "")
	{
		var oldAnswer = getCookie(question);
		var inner = document.getElementById("" + question + "," + oldAnswer).innerHTML;
		
		if(oldAnswer !== ans)
		{
			setCookie(question, ans, 1);
			document.getElementById("" + question + "," + oldAnswer).innerHTML = inner.substr(23, inner.indexOf("</span>"));

			if(quizAnswerKey[question] == oldAnswer)
			{
				correct--;
			}
			checkAnswer(question, ans);
		}
	}

	debug();
}

function checkAnswer(question, ans)
{

	var inner = document.getElementById("" + question + "," + ans).innerHTML;
		
		if(quizAnswerKey[question] == ans) // Answer is correct
		{
			
			document.getElementById("" + question + "," + ans).innerHTML = "<span class='selected'>" + inner + "</span>";
			correct++;
			
			if(getCookie("correct") == "") // We haven't answered a question before, so we're at the beginning of the quiz
			{
				//setCookie
				setCookie("correct", correct, 1);
			}
			else
			{
				// update cookie
				setCookie("correct", correct, 1);				
			}
		} 
		else // Answer is incorrect
		{
			document.getElementById("" + question + "," + ans).innerHTML = "<span class='selected'>" + inner + "</span>";
			//document.getElementById("" + question + "," + ans).innerHTML += "&nbsp<font color='red'>X</font>";
		}

}

// Called when the quiz is finished
function quizFinished()
{	
	if(correct != curQuestionId) // They didn't get all the questions right
	{
		// Tell them they didn't get them all right, then redirect
		// Do this in a better way, probably with JQuery fade in or something
		clearCookie();
		alert("You didn't get all the questions right, going back to the relevant slides.");
		
		deleteCookie("curSlide"); // Make sure they go back to the first slide.
		var newNum = 1;
		if(curQuiz == 1)
		{
			newNum = 1;
		}
		else if(curQuiz == 2)
		{
			newNum = 13;
		}
		else if(curQuiz == 3)
		{
			newNum = 20;
		}
		setCookie("curSlide", newNum);
		deleteCookie("cont" + curQuiz);
		window.location="GLA.html";
	}
	else // They got all the questions correct
	{
		setCookie("cont" + curQuiz, 1, 1);
		clearCookie();
		alert("Congratulations! You got all the questions right.");
		window.location="GLA.html";
	}
}
// Add to the arrays holding the questions and answers. All variables are strings except correctAnswer, which is an int.
function addQuestion(question, answer1, answer2, answer3, answer4, correctAnswer)
{
	// Currently set up for only 4 questions. Doubtful more would be needed, but if so rewrite for modularity
	quizQuestions[curQuestionId] = question;
	quizAnswers[curQuestionId] = [];
	quizAnswers[curQuestionId][0] = answer1;
	quizAnswers[curQuestionId][1] = answer2;
	quizAnswers[curQuestionId][2] = answer3;
	quizAnswers[curQuestionId][3] = answer4;
	quizAnswerKey[curQuestionId] = correctAnswer-1;
	curQuestionId++; // Keep track of the total number of questions
}

function showCookies()
{
	alert(document.cookie);
}

function clearCookie()
{
	deleteCookie("correct");
	deleteCookie("answered");
	deleteCookie("submitted");
	
	for(var i = 0; i < curQuestionId; ++i)
	{
		deleteCookie(""+i);
	}
//	window.location=curPage;
}

function clearQuiz()
{
	var clear = confirm("All of your progress will be lost! Are you sure you would like to continue?");
	
	if(clear)
	{
		clearCookie();
	}
}

function debug()
{
	//document.getElementById("test").innerHTML = correct + "/" + curQuestionId + "<br>";
	document.getElementById("test").innerHTML = "Questions answered: " + answered + "/" + curQuestionId;
}